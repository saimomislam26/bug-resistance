import React, { useState } from 'react'
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  NavbarText
} from 'reactstrap';
// import Nav from 'react-bootstrap/Nav';
// import Navbar from 'react-bootstrap/Navbar';
// import Container from 'react-bootstrap/Container';

import logo from '../../images/logo.png'
import { Link } from 'react-router-dom'
const NavbarTop = () => {
  const [visible, setVisible] = useState(false)
  const [isOpen, setIsOpen] = useState(false);

  const toggle = () => setIsOpen(!isOpen);

  const toggleVisible = () => {
    const scrolled = document.documentElement.scrollTop;
    if (scrolled > 300) {
      setVisible(true)
    }
    else if (scrolled <= 300) {
      setVisible(false)
    }
  };


  window.addEventListener('scroll', toggleVisible);
  return (
    <>
      {/* <!-- header-section start --> */}
      <header id="header-section" style={{ backgroundColor: '#5c2cc5' }}>
        <div class="overlay">
          <div class="container">
            <div class="row d-flex header-area">
              {/* React Bootstrap */}

              {/* <Navbar collapseOnSelect className=' p-0' expand="md">
                <Container>
                <div class="logo-section flex-grow-1 d-flex align-items-center">
                  <Link class="site-logo site-title" to='/'><img src={logo} alt="site-logo" /></Link>
                </div>
                  <Navbar.Toggle aria-controls="basic-navbar-nav" />
                  <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="me-auto navbar-collapsed " >
                    
                    <ul class="navbar-nav main-menu ml-auto" >
                    <li className='visible-list' ><Link to="/">Home</Link></li>
                    <li className='visible-list' ><Link to="/student">About</Link></li>
                    <li className='visible-list' ><Link to="/courseadmission">Course Admission</Link></li>
                    <li className='visible-list' ><Link to="/" >Career-Blog</Link></li>
                    <li className='visible-list' ><Link to='' >Contact</Link></li>
                  </ul>  
                    </Nav>
                  </Navbar.Collapse>
                </Container>
              </Navbar> */}



              {/* React Bootstrap */}



              {/* ReactStrap */}
              <Navbar className='navbar p-0' light expand="md">
                <div class="logo-section flex-grow-1 d-flex align-items-center">
                  <Link class="site-logo site-title" to='/'><img src={logo} alt="site-logo" /></Link>
                </div>
                <NavbarToggler onClick={toggle} />
                <Collapse isOpen={isOpen} navbar>
                  <Nav className="mr-auto navbar-collapsed" navbar>
                  <ul class="navbar-nav main-menu ml-auto" >
                    <li className='visible-list' ><Link to="/">Home</Link></li>
                    <li className='visible-list' ><Link to="/student">About</Link></li>
                    <li className='visible-list' ><Link to="/courseadmission">Course Admission</Link></li>
                    <li className='visible-list' ><Link to="/" >Career-Blog</Link></li>
                    <li className='visible-list' ><Link to='' >Contact</Link></li>
                  </ul>  
                 
                  </Nav>
                </Collapse>
              </Navbar>


              {/* ReactStrap*/}


              {/* <div class="logo-section flex-grow-1 d-flex align-items-center">
                <Link class="site-logo site-title" to='/'><img src={logo} alt="site-logo"/></Link>
              </div> */}
              {/* <button class="navbar-toggler ml-auto collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
              </button>
              <nav class="navbar navbar-expand-lg p-0">
              <div class="logo-section flex-grow-1 d-flex align-items-center">
                <Link class="site-logo site-title" to='/'><img src={logo} alt="site-logo"/></Link>
              </div>
                <div class="navbar-collapse collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav main-menu ml-auto">
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="/student">About</Link></li>
                    <li><Link to="/courseadmission">Course Admission</Link></li>
                    <li><Link to="/">Career-Blog</Link></li>
                    <li ><Link to='' >Contact</Link></li>
                  </ul>  
                </div>
              </nav> */}
            </div>
          </div>
        </div>
      </header>
      {/* <!-- header-section end --> */}
    </>
  )
}

export default NavbarTop